#include <stdio.h>

main()
{
   unsigned int a,b;

   a=1;
   while (a!=0)
   {
	 b = a;
	 printf("b=%d\n",b);
	 a++;
   }
   /*printf("max=%d\n",b);*/
}