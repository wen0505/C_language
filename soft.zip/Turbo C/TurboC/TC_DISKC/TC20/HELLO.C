/*	HELLO.C -- Hello, world */

#include <stdio.h>

main()
{
	printf("hello, world");
}
