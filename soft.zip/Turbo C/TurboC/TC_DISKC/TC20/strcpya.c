#include <stdio.h>

void strcpy(char *s, char *t);

main()
{
    char ss[]="Hello";
    char tt[100];
    strcpy(tt,ss);
    printf("string=\"%s\"",tt);
}

/* strcpy: copy t to s; array subscript version */
void strcpy(char *s, char *t)
{
     int i;    
     i = 0;
     while((s[i] = t[i]) != '\0')
          i++;
}