#include <stdio.h>

main()
{
   int a;
   double b;
   char c[10];

   scanf("%d",&a);
   printf("a=%d\n",a);

   scanf("%lf",&b);
   printf("b=%lf\n",b);

   scanf("%s",c);
   printf("c=%s\n",c);
}
