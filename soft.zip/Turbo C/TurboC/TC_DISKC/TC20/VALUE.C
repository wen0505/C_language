#include <stdio.h>

main()
{
   char k,kk;
   unsigned char ku;
   short int sk,skk;
   unsigned short int sku;
   int ik,ikk;
   unsigned int iku;
   long int lk,lkk;
   unsigned long int lku;

   /* char */
   k=1;
   while (k>0) k<<=1;
   printf("min char = %d, ",k);
   k=1;
   while (k>0)
   {
      k=(k<<1)|1;
      if (k>0) kk=k;
   }
   printf("max char = %d (%x)\n",kk,kk);
   ku=0;
   ku=~ku;
   printf("min unsigned char = 0, max unsigned char = %u (%x)\n",ku,ku);
   /* short int */
   sk=1;
   while (sk>0) sk<<=1;
   printf("min short = %d, ",sk);
   sk=1;
   while (sk>0)
   {
      sk=(sk<<1)|1;
      if (sk>0) skk=sk;
   }
   printf("max short = %d (%x)\n",skk,skk);
   sku=0;
   sku=~sku;
   printf("min unsigned short = 0, max unsigned short = %u (%x)\n",sku,sku);
   /* int */
   ik=1;
   while (ik>0) ik<<=1;
   printf("min int = %d, ",ik);
   ik=1;
   while (ik>0)
   {
      ik=(ik<<1)|1;
      if (ik>0) ikk=ik;
   }
   printf("max int = %d (%x)\n",ikk,ikk);
   iku=0;
   iku=~iku;
   printf("min unsigned int = 0, max unsigned int = %u (%x)\n",iku,iku);
   /* long int */
   lk=1;
   while (lk>0) lk<<=1;
   printf("min long = %ld, ",lk);
   lk=1;
   while (lk>0)
   {
      lk=(lk<<1)|1;
      if (lk>0) lkk=lk;
   }
   printf("max long = %ld (%lx)\n",lkk,lkk);
   lku=0;
   lku=~lku;
   printf("min unsigned long = 0, max unsigned long = %lu (%lx)\n",lku,lku);
}
