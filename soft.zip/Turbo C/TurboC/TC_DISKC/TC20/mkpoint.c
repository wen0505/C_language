#include <stdio.h>
#include <math.h>

struct point makepoint(int x, int y);

struct point {
     int x;
     int y;
};

main()
{
   /* struct point pt1 = {320, 200}; */
   /* struct point pt2 = {30, 40}; */
   struct point pt1;
   struct point pt2;
   double dist;

   pt1 = makepoint(320, 200);
   pt2 = makepoint(30, 40);
   printf("%d, %d\n", pt1.x, pt1.y);
   dist = sqrt((double)pt2.x*pt2.x + (double)pt2.y*pt2.y);
   printf("dist = %lf\n",dist);
}

/* makepoint: make a point from x and y components */
struct point makepoint(int x, int y)
{
     struct point temp;

     temp.x = x;
     temp.y = y;
     return temp;
}
