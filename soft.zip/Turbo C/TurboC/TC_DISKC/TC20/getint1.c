#include <stdio.h>
#include <ctype.h>

#define BUFSIZE 100

int getint(int *);
int getch(void);
void ungetch(int);

char buf[BUFSIZE];  /* buffer for ungetch */
int bufp = 0;  /* next free position in buf */

main()
{
   int a,b;

   a = getint(&b);
   printf("a=%d, b=%d\n",a,b);
}

int getch(void)  /* get a (possibly pushed back) character */
{
    return (bufp > 0) ? buf[--bufp] : getchar();
}
void ungetch(int c)  /* push character back on input */
{
    if (bufp >= BUFSIZE)
        printf("ungetch: too many characters\n");
    else
        buf[bufp++] = c;
}

/* getint: get next integer from input into *pn */
int getint(int *pn)
{
    int c, sign;
    while (isspace(c = getch()))
           ;     /* skip white space */
    if(!isdigit(c) && c != EOF && c != '+' && c != '-')
    {
        ungetch(c); /* it's not a number */
        return 0;
    }/* if */
    sign = (c == '-') ? -1 : 1;
    if ( c == '+' || c == '-')
        c = getch();
    for (*pn = 0; isdigit(c); c = getch())
        *pn = 10 * *pn + (c - '0');  /* �`�N *pn */
    *pn *= sign;
    if (c != EOF)     /* EOF �b stdio.h �� */
        ungetch(c);
    return c;
}
