#include <stdio.h>

void strcpy(char *s, char *t);

main()
{
    char ss[]="Hello";
    char tt[100];
    strcpy(tt,ss);
    printf("string=\"%s\"\n",tt);
}

/* strcpy: copy t to s; array pointer version 1 */
void strcpy(char *s, char *t)
{
     while((*s = *t) != '\0') {
          s++;
          t++;
     }
}
