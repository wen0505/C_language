#include <stdio.h>

void printd(int n);

main()
{
    int a;

    a = 123;
    printd(a);
}

/* printd: print n in decimal */
void printd(int n)
{
   if (n < 0) {
       putchar('-');
       n = -n;
   }
   if (n / 10) /* �Y n/10 ������ 0 */
       printd(n / 10);   /* recursive call myself */
   putchar(n % 10 + '0');
}
