#include <stdio.h>

#define LOWER 100    /* lower limit table */
#define UPPER 500  /* upper limit */
#define STEP  10   /* step size */

/* print Fahrenheit-Celsius table */
main()
{
    int fahr;
    for (fahr = LOWER; fahr <= UPPER; fahr = fahr + STEP)
	printf("%3d %6.1f\n",fahr, (5.0/9.0)* (fahr-32));
}
