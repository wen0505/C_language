#include <stdio.h>
#include <math.h>

struct point {
     int x;
     int y;
};

main()
{
   struct point pt1 = {320, 200};
   struct point pt2 = {30, 40};
   double dist;

   printf("%d, %d\n", pt1.x, pt1.y);
   dist = sqrt((double)pt2.x*pt2.x + (double)pt2.y*pt2.y);
   printf("dist = %lf\n",dist);
}
