#include <stdio.h>

int strcmp(char *s, char *t);

main()
{
    int index;
    char ss[]="Hello";
    char tt[]="Hello1";
    index=strcmp(tt,ss);
    if (index==0)
       printf("ss=tt\n");
    else
       printf("ss!=tt\n");
}

/* strcmp: return < 0 if s<t, 0 if s==t, >0 if s>t */
int strcmp(char *s, char *t)
{
     for ( ; *s == *t; s++, t++)
        if (*s == '\0')
            return 0;
     return *s - *t;
}
