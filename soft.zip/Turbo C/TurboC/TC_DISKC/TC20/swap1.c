#include <stdio.h>

void swap(int *px, int *py);

main()
{
    int a = 10;
    int b = 5;
    printf("initial: a=%d, b=%d\n",a,b);
    swap(&a,&b);
    printf("swap: a=%d, b=%d\n",a,b);
}

void swap(int *px, int *py)   /* �� *px �P *py �洫 */
{
     int temp; /* �`�N���n�g�� int *temp; */
     
     temp = *px; /* �`�N temp = ... */
     *px = *py;
     *py = temp; /* �`�N ... = temp */
}
