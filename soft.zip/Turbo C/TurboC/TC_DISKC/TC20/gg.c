#include <stdio.h>

int ff(){
    int ans = 0;
    return ans++;
}
int gg(){
    static int ans = 0;
    return ans++;
}
int main(){
    printf("ff: %d %d %d\n", ff(), ff(), ff());
    printf("gg: %d %d %d\n", gg(), gg(), gg());
}
