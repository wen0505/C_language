#include <stdio.h>

#define NUMBER 5
void qsort(int v[], int left, int right);

main()
{
    int a[NUMBER], i;

    a[0] = 92;
    a[1] = 88;
    a[2] = 76;
    a[3] = 80;
    a[4] = 68;
    printf("*** Initial result ***\n");
    for (i = 0; i < NUMBER; i++)
	printf("a[%d] = %d\n", i, a[i]);
    qsort(a, 0, NUMBER-1);
    printf("*** Final result ***\n");
    for (i = 0; i < NUMBER; i++)
        printf("a[%d] = %d\n", i, a[i]);
}

/* qsort: sort v[left]...v[right] into increasing order */
void qsort(int v[], int left, int right)
{
     int i, last;
     void swap(int v[], int i, int j);

     if (left >= right) /* do nothing if array contains */
          return;       /* fewer than two elements */
     swap(v, left, (left + right)/2); /* move partition elem */
     last = left;  /* to v[0] */
     for (i = left + 1; i <= right; i++) /* partition */
          if (v[i] < v[left])
               swap(v, ++last, i);
     swap(v, left, last);  /* restore partition elem */
     qsort(v, left, last-1);
     qsort(v, last+1, right);
}

/* swap: interchange v[i] and v[j] */
void swap(int v[], int i, int j)
{
     int temp;
     temp = v[i];
     v[i] = v[j];
     v[j] = temp;
}