#include <stdio.h>

int strlen(char *s);

main()
{
    int a;
    char ss[]="Hello";
    a = strlen(ss);
    printf("string length of \"%s\" = %d\n",ss,a);
}

/* strlen: return length of string s */
int strlen(char *s)
{
    int n;

    for (n = 0; *s != '\0'; s++)
        n++;
    return n;
}
