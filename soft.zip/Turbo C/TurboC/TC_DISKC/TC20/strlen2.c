#include <stdio.h>

int strlen(char *s);

main()
{
    int a;
    char ss[]="Hello";
    a = strlen(ss);
    printf("string length of \"%s\" = %d\n",ss,a);
}

/* strlen: return length of string */
int strlen(char *s)
{
    char *p = s;

    while(*p != '\0')
        p++;
    return p - s;
}
