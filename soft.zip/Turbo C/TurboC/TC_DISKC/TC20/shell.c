#include <stdio.h>

#define NUMBER 5

void shellsort(int v[], int n);

main()
{
    int a[NUMBER], i;

	a[0] = 88;
	a[1] = 92;
	a[2] = 68;
	a[3] = 80;
	a[4] = 76;
    shellsort(a, NUMBER);
    printf("*** Final result ***\n");
    for (i = 0; i < NUMBER; i++)
        printf("a[%d] = %d\n", i, a[i]);
}

/* shellsort: sort v[0]...v[n-1] into increasing order */
void shellsort(int v[], int n)
{
     int gap, i, j, temp;

     for (gap = n/2; gap > 0; gap /=2)
         for (i = gap; i < n; i++)
             for (j = i-gap; j>=0&&v[j]>v[j+gap]; j-=gap)
             {
                 temp = v[j];
                 v[j] = v[j+gap];
                 v[j+gap] = temp;
             }
}
