#include <stdio.h>

int atoi(char s[]);

main()
{
	char x[] = "12500";
    int a;

    a = atoi(x);
    printf("%d\n", a);
}

/* atoi: convert s to integer */
int atoi(char s[])
{
    int i, ans;

    ans = 0;
    for(i = 0; s[i] >= '0' && s[i] <= '9'; ++i)
        ans = 10 * ans + (s[i] - '0');
    return ans;
}