#include <stdio.h>

unsigned getbits(unsigned x, int p, int n);

main()
{
    int n,p;
    unsigned x;

    x=31;
    n=2;
    p=5;
    printf("%d\n", getbits(x,p,n));
}

/* getbits: get n bits from position p */
unsigned getbits(unsigned x, int p, int n)
{
       return (x >> (p+1-n)) & ~(~0 << n);
}
