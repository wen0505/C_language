#include <stdio.h>
#include <math.h>

struct point {
     int x;
     int y;
};

main()
{
   struct point origin = {320, 200};
   struct point *pp;

   printf("%d, %d\n", origin.x, origin.y);
   pp = &origin;
   printf("origin is (%d,%d)\n", (*pp).x, (*pp).y);
   printf("origin is (%d,%d)\n", pp->x, pp->y);
}
