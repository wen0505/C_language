#include <stdio.h>

int strcmp(char *s, char *t);

main()
{
    int index;
    char ss[]="Hello";
    char tt[]="Hello1";
    index=strcmp(tt,ss);
    if (index==0)
       printf("ss=tt\n");
    else
       printf("ss!=tt\n");
}

/* strcmp: return < 0 if s<t, 0 if s==t, >0 if s>t */
int strcmp(char *s, char *t)
{
     int i;
     i = 0;
     for (i = 0; s[i] == t[i]; i++)
        if (s[i] == '\0')
            return 0;
     return s[i] - t[i];
}