#include <stdio.h>
#include <string.h>


/* int strlen(char s[]);*/

main()
{
    int a;
	a = strlen("Hello!11");
    printf("string length = %d\n",a);
}

/* strlen: return length of s */
/*
int strlen(char s[])
{
      int i;
      i = 0;
      while (s[i]!='\0')
            ++i;
      return i;
}
*/
