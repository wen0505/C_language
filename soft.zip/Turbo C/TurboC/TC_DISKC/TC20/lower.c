#include <stdio.h>

int lower(int c);

main()
{
    char a;

	a = 'H';
    printf("%c\n", lower(a));
}

int lower(int c)
{
    if (c >= 'A' && c <= 'Z')
        return c - 'A' + 'a';
    else
        return c;
}
