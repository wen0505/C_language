/*	HELLO.C -- Hello, world */

#include <stdio.h>

main()
{
    char s[]="hello, world";
    int max = 10;
    printf("%.*s\n",max,s);
    max = 15;
    printf("%.*s\n",max,s);
    printf("*************\n");
    printf("%s\n",s);
    printf("%10s\n",s);
    printf("%.10s\n",s);
    printf("%-10s\n",s);
    printf("%.15s\n",s);
    printf("%-15s\n",s);
    printf("%15.10s\n",s);
    printf("%-15.10s\n",s);
}